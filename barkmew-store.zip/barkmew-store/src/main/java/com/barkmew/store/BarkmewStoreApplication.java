package com.barkmew.store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BarkmewStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BarkmewStoreApplication.class, args);
	}

}
